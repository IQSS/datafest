README.md

###NAME

##Overview
Our code will demonstrate the different ways it is possible to calculate the value of pi, done in either 

##Installation

##Usage


##Getting help


## Contributors

## Reference

## Licensing


